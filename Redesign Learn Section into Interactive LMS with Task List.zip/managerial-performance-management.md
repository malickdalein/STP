---
title: "Managerial Performance Management"
instructor: "Professor Joseph Piotroski"
modules: 7
estimated_time: "8-10 hours"
description: "Cost-Volume-Profit Analysis, Profitability Measurement, Balanced Scorecard"
tasks:
  - text: "Complete Module 1: Cost-Volume-Profit Analysis"
    type: "module"
  - text: "Complete Module 2: Measuring and Managing Profitability"
    type: "module"
  - text: "Read Wilderness Holdings case study"
    type: "reading"
  - text: "Attend Live Session: Balanced Scorecard (Modules 3 & 4)"
    type: "session"
  - text: "Complete Post-Work: Modules 5-7"
    type: "module"
resources:
  - name: "Professor Profile"
    type: "pdf"
    size: "2.1 MB"
  - name: "Topic Overview"
    type: "pdf"
    size: "1.8 MB"
  - name: "Wilderness Holdings Case"
    type: "pdf"
    size: "3.2 MB"
---

