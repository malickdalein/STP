# Stanford GSB LMS with Netlify CMS - Deployment Instructions

## Overview

This updated version of the Stanford GSB Learning Management System now includes **Netlify CMS** integration, allowing you to easily manage content through a user-friendly web interface without touching any code.

## What's New

### Netlify CMS Integration
- **Content Management Interface**: Access at `yoursite.com/admin/` after deployment
- **User-Friendly Editing**: Add, edit, and organize content through a visual interface
- **Git-Based**: All content changes are automatically saved to your repository
- **Real-Time Updates**: Changes appear on your live site immediately after publishing

### Content You Can Manage
1. **Site Settings**: Title, description, program information
2. **Learning Outcomes**: Add or modify learning objectives
3. **Faculty Sessions**: Create, edit, or remove faculty sessions with tasks and resources
4. **Team Sessions**: Manage team sessions and their content
5. **Additional Resources**: Organize supplementary materials by category

## Deployment Steps

### Step 1: Deploy to Netlify
1. Go to [netlify.com](https://netlify.com) and log in
2. Drag and drop the `dist` folder from `stanford-gsb-lms-cms-deployment.zip`
3. Wait for deployment to complete

### Step 2: Enable Netlify Identity (Required for CMS)
1. In your Netlify dashboard, go to **Site settings** → **Identity**
2. Click **Enable Identity**
3. Under **Registration preferences**, select **Invite only** (recommended for security)
4. Under **Git Gateway**, click **Enable Git Gateway**

### Step 3: Invite Users to Access CMS
1. In **Identity** tab, click **Invite users**
2. Enter email addresses of people who should have content editing access
3. They'll receive an email invitation to set up their account

### Step 4: Access the CMS
1. Go to `yoursite.com/admin/` (replace with your actual Netlify URL)
2. Log in with the account you created
3. Start managing your content!

## Using the CMS

### Content Structure
The CMS is organized into these sections:

**Site Settings**
- General site information (title, description)

**Learning Outcomes**
- List of learning objectives for the program

**Faculty Sessions**
- Individual session pages with:
  - Title, instructor, modules, estimated time
  - Task lists with different types (module, reading, video, session, assignment)
  - Resource downloads with file sizes and types

**Team Sessions**
- Team-based learning sessions with:
  - Expert information and session details
  - Task management
  - Resource organization

**Additional Resources**
- Supplementary materials organized by category
- External links and downloadable resources

### Adding New Content
1. Navigate to the appropriate section in the CMS
2. Click **New [Content Type]**
3. Fill in the required fields
4. Click **Publish** to make changes live

### Editing Existing Content
1. Click on any existing content item
2. Make your changes
3. Click **Publish** to update the live site

## Technical Details

### File Structure
```
dist/
├── admin/                 # CMS interface
│   ├── index.html        # CMS admin page
│   └── config.yml        # CMS configuration
├── content/              # Content files (managed by CMS)
│   ├── settings/
│   ├── faculty-sessions/
│   ├── team-sessions/
│   └── additional-resources.md
└── [other built files]
```

### Content Format
- All content is stored as Markdown files with YAML frontmatter
- The React app automatically loads content from these files
- Changes made in the CMS update these files via Git

## Benefits of This Setup

✅ **No Code Required**: Content editors never need to touch code
✅ **Version Control**: All changes are tracked in Git
✅ **Instant Updates**: Changes appear immediately on the live site
✅ **Collaborative**: Multiple users can manage content
✅ **Backup**: Content is safely stored in your repository
✅ **Flexible**: Easy to add new content types or modify existing ones

## Support

If you need help:
1. **Netlify CMS Documentation**: [netlifycms.org/docs](https://netlifycms.org/docs)
2. **Netlify Identity Setup**: [docs.netlify.com/visitor-access/identity](https://docs.netlify.com/visitor-access/identity)

Your Stanford GSB LMS is now ready with full content management capabilities! 🚀

