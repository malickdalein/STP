---
title: "Human Resources: Recruitment, Retention & Rewards"
expert: "Paul Kasimu"
estimated_time: "5-6 hours"
description: "Goal setting, organizational structure, performance management"
tasks:
  - text: "Complete HR Survey (one week prior to session)"
    type: "survey"
  - text: "Watch Video 1: Goal Setting (13 min)"
    type: "video"
  - text: "Watch Video 2: Organizational Structure (22 min)"
    type: "video"
  - text: "Attend Leader & Team Session"
    type: "session"
resources:
  - name: "Paul Kasimu Profile"
    type: "pdf"
    size: "1.4 MB"
  - name: "Topic Overview"
    type: "pdf"
    size: "2.0 MB"
  - name: "HR Survey"
    type: "link"
    size: "Online"
    url: "https://example.com/hr-survey"
---

