# Stanford GSB LMS - Netlify Deployment Instructions

## Quick Deployment Guide

Follow these simple steps to deploy your Stanford GSB Learning Management System to Netlify:

### Step 1: Download the Deployment Package
- Download the `stanford-gsb-lms-deployment.zip` file provided
- Extract the contents to see the `dist` folder

### Step 2: Access Netlify
1. Go to [netlify.com](https://netlify.com)
2. Sign up for a free account or log in if you already have one
3. Once logged in, you'll see your dashboard

### Step 3: Deploy Your Site
1. **Option A - Drag & Drop (Easiest):**
   - On your Netlify dashboard, look for the section that says "Want to deploy a new site without connecting to Git?"
   - Drag the entire `dist` folder (not the zip file) directly onto the deployment area
   - Netlify will automatically upload and deploy your site

2. **Option B - Manual Upload:**
   - Click "Add new site" → "Deploy manually"
   - Click "Choose folder" and select the `dist` folder
   - Click "Deploy site"

### Step 4: Access Your Live Site
- After deployment (usually takes 1-2 minutes), Netlify will provide you with a live URL
- The URL will look something like: `https://amazing-name-123456.netlify.app`
- You can customize this URL in your site settings if desired

### Step 5: Optional Customizations
- **Custom Domain:** You can add your own domain name in Site settings → Domain management
- **Site Name:** Change the auto-generated name in Site settings → General → Site details

## What's Included in the Deployment Package

The deployment package contains:
- Complete built React application
- All Stanford GSB styling and branding
- Interactive task management system
- Responsive design for desktop and mobile
- All course content and resources organized by tabs

## Features of Your Deployed LMS

✅ **Interactive Task Lists** - Students can check off completed tasks
✅ **Progress Tracking** - Visual progress bar shows completion status  
✅ **Tabbed Navigation** - Overview, Faculty Sessions, Team Sessions, Resources
✅ **Stanford GSB Branding** - Official colors and typography
✅ **Responsive Design** - Works on all devices
✅ **Clean Interface** - Simplified, professional design
✅ **Resource Downloads** - Easy access to PDFs and materials

## Support

If you encounter any issues during deployment:
1. Ensure you're uploading the `dist` folder contents, not the zip file
2. Check that all files were extracted properly
3. Netlify's support documentation is excellent: [docs.netlify.com](https://docs.netlify.com)

Your Stanford GSB LMS is ready to go live! 🚀

