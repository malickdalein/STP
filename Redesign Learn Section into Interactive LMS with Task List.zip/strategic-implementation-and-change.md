---
title: "Strategic Implementation and Change"
instructor: "Professor Jesper Sørensen"
modules: 1
estimated_time: "6-7 hours"
description: "PARC Framework, Organizational Capabilities, Change Management"
tasks:
  - text: "Read ReleaseMyAd - PARC Model case"
    type: "reading"
  - text: "Watch McAfee Case Vignette (4 min)"
    type: "video"
  - text: "Watch PARC Framework video (11 min)"
    type: "video"
  - text: "Watch Managing Capabilities video (5 min)"
    type: "video"
  - text: "Attend Faculty Session"
    type: "session"
resources:
  - name: "Faculty Profile"
    type: "pdf"
    size: "1.9 MB"
  - name: "Topic Overview"
    type: "pdf"
    size: "2.3 MB"
  - name: "ReleaseMyAd Case"
    type: "pdf"
    size: "3.8 MB"
  - name: "Strategy and Organizational Design"
    type: "pdf"
    size: "5.2 MB"
---

