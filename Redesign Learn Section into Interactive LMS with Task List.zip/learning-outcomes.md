---
outcomes:
  - text: "Assess organizational capabilities and identify new capabilities needed"
  - text: "Explore paths to implement organizational change"
  - text: "Understand global and local talent trends and performance management"
  - text: "Define key performance indicators and use Balanced Scorecard framework"
  - text: "Model costs and perform financial analysis for growth opportunities"
  - text: "Understand financing sources and governance practices"
  - text: "Develop a coherent transformation plan with clear 2-3 year actions"
---

