---
categories:
  - title: "Managerial Performance Measurement"
    icon: "TrendingUp"
    items:
      - name: "Chapter 13: Flexible Budgets & Cost Variances"
        type: "pdf"
      - name: "Chapter 14: Strategy & Balanced Scorecard"
        type: "pdf"
      - name: "Using Balanced Scorecard - Harvard Business Review"
        type: "link"
        url: "https://hbr.org/balanced-scorecard"
  - title: "Corporate Governance"
    icon: "Building"
    items:
      - name: "IFC Family Business Governance Handbook"
        type: "link"
        url: "https://ifc.org/governance-handbook"
      - name: "Board Composition Matrix Tool"
        type: "tool"
      - name: "Sample Authority Matrix"
        type: "pdf"
---

