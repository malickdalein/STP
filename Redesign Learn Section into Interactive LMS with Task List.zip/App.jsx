import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Checkbox } from '@/components/ui/checkbox.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { 
  BookOpen, 
  Users, 
  FileText, 
  CheckCircle, 
  Clock, 
  Download,
  ExternalLink,
  Target,
  TrendingUp,
  Building,
  Play,
  Calendar,
  ChevronRight
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import './App.css'

// Content loader functions
const loadContent = async () => {
  try {
    // Load settings
    const settingsResponse = await fetch('/content/settings/general.md')
    const settingsText = await settingsResponse.text()
    const settings = parseMarkdown(settingsText)

    // Load learning outcomes
    const outcomesResponse = await fetch('/content/learning-outcomes.md')
    const outcomesText = await outcomesResponse.text()
    const outcomes = parseMarkdown(outcomesText)

    // Load faculty sessions
    const facultySessions = await Promise.all([
      loadSession('/content/faculty-sessions/managerial-performance-management.md'),
      loadSession('/content/faculty-sessions/corporate-governance.md'),
      loadSession('/content/faculty-sessions/strategic-implementation-and-change.md'),
      loadSession('/content/faculty-sessions/financing-your-growth.md')
    ])

    // Load team sessions
    const teamSessions = await Promise.all([
      loadSession('/content/team-sessions/human-resources.md'),
      loadSession('/content/team-sessions/t-plan-preparation.md')
    ])

    // Load additional resources
    const resourcesResponse = await fetch('/content/additional-resources.md')
    const resourcesText = await resourcesResponse.text()
    const additionalResources = parseMarkdown(resourcesText)

    return {
      settings,
      outcomes,
      facultySessions: facultySessions.filter(Boolean),
      teamSessions: teamSessions.filter(Boolean),
      additionalResources
    }
  } catch (error) {
    console.error('Error loading content:', error)
    return null
  }
}

const loadSession = async (path) => {
  try {
    const response = await fetch(path)
    if (!response.ok) return null
    const text = await response.text()
    return parseMarkdown(text)
  } catch (error) {
    console.error(`Error loading session from ${path}:`, error)
    return null
  }
}

// Simple markdown frontmatter parser
const parseMarkdown = (content) => {
  const frontmatterRegex = /^---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/
  const match = content.match(frontmatterRegex)
  
  if (!match) return { data: {}, content: content }
  
  const frontmatter = match[1]
  const body = match[2]
  
  // Simple YAML parser for our specific use case
  const data = {}
  const lines = frontmatter.split('\n')
  let currentKey = null
  let currentArray = null
  
  for (const line of lines) {
    const trimmed = line.trim()
    if (!trimmed) continue
    
    if (trimmed.startsWith('- ')) {
      // Array item
      if (currentArray) {
        if (trimmed.includes(':')) {
          // Object in array
          const [key, value] = trimmed.substring(2).split(':').map(s => s.trim())
          if (currentArray.length === 0 || typeof currentArray[currentArray.length - 1] !== 'object') {
            currentArray.push({})
          }
          currentArray[currentArray.length - 1][key] = value.replace(/"/g, '')
        } else {
          // Simple array item
          currentArray.push(trimmed.substring(2).replace(/"/g, ''))
        }
      }
    } else if (trimmed.includes(':')) {
      // Key-value pair
      const colonIndex = trimmed.indexOf(':')
      const key = trimmed.substring(0, colonIndex).trim()
      const value = trimmed.substring(colonIndex + 1).trim()
      
      if (value === '') {
        // Start of array
        currentKey = key
        currentArray = []
        data[key] = currentArray
      } else {
        // Simple value
        data[key] = value.replace(/"/g, '')
        currentArray = null
      }
    } else if (trimmed.startsWith('text:') || trimmed.startsWith('type:') || trimmed.startsWith('name:') || trimmed.startsWith('size:') || trimmed.startsWith('url:')) {
      // Object property in array
      if (currentArray) {
        const [key, value] = trimmed.split(':').map(s => s.trim())
        if (currentArray.length === 0 || typeof currentArray[currentArray.length - 1] !== 'object') {
          currentArray.push({})
        }
        currentArray[currentArray.length - 1][key] = value.replace(/"/g, '')
      }
    }
  }
  
  return { data, content: body }
}

function App() {
  const [completedTasks, setCompletedTasks] = useState(new Set())
  const [activeTab, setActiveTab] = useState('overview')
  const [content, setContent] = useState(null)
  const [loading, setLoading] = useState(true)
  
  useEffect(() => {
    loadContent().then(data => {
      if (data) {
        setContent(data)
      } else {
        // Fallback to hardcoded data if content loading fails
        setContent(getDefaultContent())
      }
      setLoading(false)
    })
  }, [])
  
  const toggleTask = (taskId) => {
    const newCompleted = new Set(completedTasks)
    if (newCompleted.has(taskId)) {
      newCompleted.delete(taskId)
    } else {
      newCompleted.add(taskId)
    }
    setCompletedTasks(newCompleted)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Loading content...</p>
        </div>
      </div>
    )
  }

  if (!content) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600">Error loading content. Please try again later.</p>
        </div>
      </div>
    )
  }

  const { settings, outcomes, facultySessions, teamSessions, additionalResources } = content
  const allSessions = [...facultySessions, ...teamSessions]
  const totalTasks = allSessions.reduce((acc, session) => acc + (session.data.tasks?.length || 0), 0)
  const completedCount = completedTasks.size
  const progressPercentage = totalTasks > 0 ? (completedCount / totalTasks) * 100 : 0

  const getTaskIcon = (type) => {
    switch (type) {
      case 'module': return <BookOpen className="w-4 h-4" />
      case 'reading': return <FileText className="w-4 h-4" />
      case 'video': return <Play className="w-4 h-4" />
      case 'session': return <Users className="w-4 h-4" />
      case 'assignment': return <Target className="w-4 h-4" />
      case 'survey': return <TrendingUp className="w-4 h-4" />
      case 'preparation': return <Building className="w-4 h-4" />
      default: return <CheckCircle className="w-4 h-4" />
    }
  }

  const getResourceIcon = (type) => {
    switch (type) {
      case 'pdf': return <FileText className="w-4 h-4" />
      case 'tool': return <Target className="w-4 h-4" />
      case 'link': return <ExternalLink className="w-4 h-4" />
      default: return <Download className="w-4 h-4" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl font-bold text-primary">{settings.data.title || 'Stanford GSB'}</h1>
              <p className="text-lg text-gray-600 mt-1">{settings.data.program_title || 'Part 4: Build Your Growth Plan'}</p>
            </motion.div>
            
            <motion.div 
              className="text-right"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="text-sm text-gray-500 mb-1">Progress</div>
              <div className="flex items-center gap-3">
                <Progress value={progressPercentage} className="w-40" />
                <span className="text-sm font-medium">{completedCount}/{totalTasks}</span>
              </div>
            </motion.div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Target className="w-4 h-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="faculty" className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Faculty Sessions
            </TabsTrigger>
            <TabsTrigger value="team" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Team Sessions
            </TabsTrigger>
            <TabsTrigger value="resources" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Resources
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* Learning Outcomes */}
              <Card className="mb-8 overflow-hidden">
                <div className="bg-primary p-6 text-white">
                  <CardTitle className="flex items-center gap-2 text-xl">
                    <Target className="w-6 h-6" />
                    Learning Outcomes
                  </CardTitle>
                  <CardDescription className="text-white/90 mt-2">
                    In this final STP stage, you and your team will bring together insights learned during the program to build your company's Transformation Plan.
                  </CardDescription>
                </div>
                <CardContent className="p-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    {outcomes.data.outcomes?.map((outcome, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                        className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <CheckCircle className="w-5 h-5 text-accent mt-0.5 flex-shrink-0" />
                        <span className="text-sm leading-relaxed">{outcome.text || outcome}</span>
                      </motion.div>
                    )) || []}
                  </div>
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-200"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Total Sessions</p>
                      <p className="text-2xl font-bold text-primary">{allSessions.length}</p>
                    </div>
                    <BookOpen className="w-8 h-8 text-primary" />
                  </div>
                </motion.div>
                
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-200"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Completed Tasks</p>
                      <p className="text-2xl font-bold text-accent">{completedCount}</p>
                    </div>
                    <CheckCircle className="w-8 h-8 text-accent" />
                  </div>
                </motion.div>
                
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-200"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Progress</p>
                      <p className="text-2xl font-bold text-gray-900">{Math.round(progressPercentage)}%</p>
                    </div>
                    <Target className="w-8 h-8 text-gray-600" />
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </TabsContent>

          {/* Faculty Sessions Tab */}
          <TabsContent value="faculty">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="grid lg:grid-cols-2 gap-6"
            >
              {facultySessions.map((session, index) => (
                <SessionCard 
                  key={index}
                  session={session.data}
                  index={index}
                  completedTasks={completedTasks}
                  toggleTask={toggleTask}
                  getTaskIcon={getTaskIcon}
                  getResourceIcon={getResourceIcon}
                  sessionType="faculty"
                />
              ))}
            </motion.div>
          </TabsContent>

          {/* Team Sessions Tab */}
          <TabsContent value="team">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="grid lg:grid-cols-2 gap-6"
            >
              {teamSessions.map((session, index) => (
                <SessionCard 
                  key={index}
                  session={session.data}
                  index={index}
                  completedTasks={completedTasks}
                  toggleTask={toggleTask}
                  getTaskIcon={getTaskIcon}
                  getResourceIcon={getResourceIcon}
                  sessionType="team"
                />
              ))}
            </motion.div>
          </TabsContent>

          {/* Resources Tab */}
          <TabsContent value="resources">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="shadow-sm border border-gray-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-primary" />
                    Additional Resources
                  </CardTitle>
                  <CardDescription>
                    Supplementary materials and tools to support your learning
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-8">
                    {additionalResources.data.categories?.map((category, index) => (
                      <div key={index}>
                        <h4 className="font-medium mb-4 flex items-center gap-2">
                          {category.icon === 'TrendingUp' && <TrendingUp className="w-4 h-4 text-primary" />}
                          {category.icon === 'Building' && <Building className="w-4 h-4 text-primary" />}
                          {category.title}
                        </h4>
                        <div className="space-y-2">
                          {category.items?.map((item, itemIndex) => (
                            <motion.div key={itemIndex} whileHover={{ x: 3 }}>
                              <Button variant="ghost" size="sm" className="w-full justify-start group">
                                {getResourceIcon(item.type)}
                                <span className="ml-2 flex-1 text-left">{item.name}</span>
                                {item.type === 'link' ? 
                                  <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" /> : 
                                  <Download className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                                }
                              </Button>
                            </motion.div>
                          )) || []}
                        </div>
                      </div>
                    )) || []}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

// Session Card Component
const SessionCard = ({ session, index, completedTasks, toggleTask, getTaskIcon, getResourceIcon, sessionType }) => {
  const generateTaskId = (sessionTitle, taskIndex) => {
    return `${sessionTitle.toLowerCase().replace(/\s+/g, '-')}-task-${taskIndex}`
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.1 }}
      whileHover={{ y: -2 }}
      className="group"
    >
      <Card className="h-full overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 border border-gray-200">
        <CardHeader className="bg-gray-50 border-b border-gray-200">
          <div className="flex justify-between items-start mb-2">
            <div className="flex-1">
              <CardTitle className="text-lg leading-tight text-primary">{session.title}</CardTitle>
              <CardDescription className="mt-2">
                {sessionType === 'faculty' ? session.instructor : `Local Expert: ${session.expert}`}
              </CardDescription>
            </div>
            <Badge variant="secondary" className={sessionType === 'faculty' ? "bg-primary/10 text-primary" : "bg-accent/10 text-accent"}>
              {sessionType === 'faculty' ? `${session.modules} module${session.modules > 1 ? 's' : ''}` : 'Team Session'}
            </Badge>
          </div>
          
          <div className="flex items-center gap-1 text-sm text-gray-600">
            <Clock className="w-4 h-4" />
            {session.estimated_time}
          </div>
        </CardHeader>
        
        <CardContent className="p-6">
          <p className="text-sm text-gray-600 mb-6">{session.description}</p>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium mb-3 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-primary" />
                Tasks ({session.tasks?.filter(task => completedTasks.has(generateTaskId(session.title, session.tasks.indexOf(task)))).length || 0}/{session.tasks?.length || 0})
              </h4>
              <div className="space-y-2">
                {session.tasks?.map((task, taskIndex) => {
                  const taskId = generateTaskId(session.title, taskIndex)
                  return (
                    <motion.div
                      key={taskIndex}
                      whileHover={{ x: 3 }}
                      className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-all duration-200 group/task"
                    >
                      <Checkbox
                        checked={completedTasks.has(taskId)}
                        onCheckedChange={() => toggleTask(taskId)}
                        className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                      />
                      <div className="flex items-center gap-2 flex-1">
                        {getTaskIcon(task.type)}
                        <span className={`text-sm transition-all duration-200 ${
                          completedTasks.has(taskId) 
                            ? 'line-through text-gray-500' 
                            : 'group-hover/task:text-primary'
                        }`}>
                          {task.text}
                        </span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-gray-400 opacity-0 group-hover/task:opacity-100 transition-opacity" />
                    </motion.div>
                  )
                }) || []}
              </div>
            </div>
            
            <div>
              <h4 className="font-medium mb-3 flex items-center gap-2">
                <Download className="w-4 h-4 text-primary" />
                Resources
              </h4>
              <div className="space-y-1">
                {session.resources?.map((resource, resourceIndex) => (
                  <motion.div key={resourceIndex} whileHover={{ x: 3 }}>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start h-auto p-3 hover:bg-gray-50 group/resource"
                      onClick={() => resource.url && window.open(resource.url, '_blank')}
                    >
                      {getResourceIcon(resource.type)}
                      <span className="ml-2 text-sm flex-1 text-left">{resource.name}</span>
                      <span className="text-xs text-gray-500 mr-2">{resource.size}</span>
                      {resource.type === 'link' ? 
                        <ExternalLink className="w-3 h-3 opacity-0 group-hover/resource:opacity-100 transition-opacity" /> : 
                        <Download className="w-3 h-3 opacity-0 group-hover/resource:opacity-100 transition-opacity" />
                      }
                    </Button>
                  </motion.div>
                )) || []}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}

// Default content fallback
const getDefaultContent = () => {
  return {
    settings: { data: { title: 'Stanford GSB', program_title: 'Part 4: Build Your Growth Plan' } },
    outcomes: { 
      data: { 
        outcomes: [
          { text: 'Assess organizational capabilities and identify new capabilities needed' },
          { text: 'Explore paths to implement organizational change' },
          { text: 'Understand global and local talent trends and performance management' },
          { text: 'Define key performance indicators and use Balanced Scorecard framework' },
          { text: 'Model costs and perform financial analysis for growth opportunities' },
          { text: 'Understand financing sources and governance practices' },
          { text: 'Develop a coherent transformation plan with clear 2-3 year actions' }
        ]
      }
    },
    facultySessions: [],
    teamSessions: [],
    additionalResources: { data: { categories: [] } }
  }
}

export default App

