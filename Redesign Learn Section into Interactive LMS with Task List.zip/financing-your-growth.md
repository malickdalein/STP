---
title: "Financing Your Growth"
instructor: "Faculty Team"
modules: 1
estimated_time: "3-4 hours"
description: "Financing Sources, Investment Analysis, Financial Planning"
tasks:
  - text: "Review Topic Overview"
    type: "reading"
  - text: "Attend Faculty Session"
    type: "session"
resources:
  - name: "Topic Overview"
    type: "pdf"
    size: "2.1 MB"
  - name: "Faculty Profile"
    type: "pdf"
    size: "1.7 MB"
---

