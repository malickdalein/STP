---
title: "Corporate Governance"
instructor: "Alexey Volynets"
modules: 1
estimated_time: "4-5 hours"
description: "SME Governance, Board Composition, Authority Matrix"
tasks:
  - text: "Read IFC SME Governance Guidebook"
    type: "reading"
  - text: "Review Rockstar Clothing Company Case Study"
    type: "reading"
  - text: "Attend Faculty Session"
    type: "session"
  - text: "Create your Governance Action Plan"
    type: "assignment"
resources:
  - name: "Faculty Profile"
    type: "pdf"
    size: "1.5 MB"
  - name: "Topic Overview"
    type: "pdf"
    size: "2.0 MB"
  - name: "Rockstar Case Study"
    type: "pdf"
    size: "4.1 MB"
  - name: "IFC SME Governance Guidebook"
    type: "pdf"
    size: "8.7 MB"
  - name: "Board Composition Matrix Tool"
    type: "tool"
    size: "0.8 MB"
---

